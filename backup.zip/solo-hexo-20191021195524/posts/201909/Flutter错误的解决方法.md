title: Flutter 错误的解决方法
date: '2019-09-10 20:20:14'
updated: '2019-09-10 20:21:13'
tags: [Flutter]
permalink: /articles/2019/09/10/1568118014823.html
---
 ###  Unknown installation options: disable_input_output_paths.

1. 通过Pub依赖了三方库  
2. 执行`flutter pub get`后，ios目录下多了`Podfile`文件夹，同时有些文件内容也会发生修改；  
3. 项目运行出错，提示信息是`pod install`中出的错，并显示`Unknown installation options: disable_input_output_paths.`以及一些关于CocoaPods版本的日志。同样，我们如果在终端，进入ios目录，执行pod install命令的话，在终端也会直接提示`Unknown installation options: disable_input_output_paths.`这个错误。

#### 解决方法

1. 打开终端，输入`sudo gem install cocoapods`来升级CocoaPods；  
如果遇到  
`ERROR: While executing gem ... (Gem::FilePermissionError)`  
`You don't have write permissions for the /usr/bin directory.`  
这个错误的话就改用`sudo gem install cocoapods -n /usr/local/bin`命令即可。

#### 其他情况  当你执行上面的命令后 如果能运行成功 那么恭喜你 解决了问题 但是如果还报其他错误 请看下面
1. 执行 `sudo gem install cocoapods` 报 `ERROR:  Could not find a valid gem 'cocoapods' (>= 0), here is why:
          Unable to download data from https://gems.ruby-china.org/ - bad response Not Found 404 (https://gems.ruby-china.org/specs.4.8.gz)` 这是因为ruby-china的镜像不再维护了
2.  执行如下命令 删除 镜像源 `gem source -r https://gems.ruby-china.org/ ` 
3. 再设置新的镜像源 命令如下 `gem sources -a https://rubygems.org/` rubygems 在国内虽然慢了一点 但是还是勉强能用的  
4. 查看是否设置成功 `gem source -l`  
5. 如果还是没成功 就更新下缓存 `gem source -u`
6. 更换源成功后 再重复解决方法的第一二步就可以了


title: Android 开机 自动启动应用
date: '2019-09-08 10:34:10'
updated: '2019-09-08 10:34:10'
tags: [Android, AndroidReact平板开发]
permalink: /articles/2019/09/08/1567910049966.html
---
### APK 开机自动启动应用

1. 在MainActivity的同级目录下新建BootBroadcastReceiver类 文件 代码如下 注意 还需要导入自己的应用包名 如：package com.recyclingbarrelapk;

```java

package com.recyclingbarrelapk;

import android.content.BroadcastReceiver;

import android.content.Context;

import android.content.Intent;

import android.widget.Toast;

public class BootBroadcastReceiver extends BroadcastReceiver {

public static final String TAG = "BootBroadcastReceiver";

@Override

public void onReceive(Context context, Intent intent) {

String action = intent.getAction().toString();

if (action.equals(Intent.ACTION_BOOT_COMPLETED)) {

// u can start your service here

Toast.makeText(context, "boot completed action has got", Toast.LENGTH_LONG).show();

Intent intent1 = new Intent(context, MainActivity.class);

intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

context.startActivity(intent1);

return;

}

}

}

```

2. 在AndroidMainifest.xml 文件里面加上 接收广播事件的监听权限

```xml

<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />

```

3. 添加manifest配置，添加注册服务(某些IDE可能需要把name改成BootBroadcastReceiver的完整路径)： 这个是和Activity 同级的

```xml

<!-- 开机自启动广播接收 -->

<receiver android:name=".BootBroadcastReceiver" >

<intent-filter>

<action android:name="android.intent.action.BOOT_COMPLETED" />

</intent-filter>

</receiver>

```

4. 开机广播测试，可用ADB发送BOOT_COMPLETED（无需反复重启机器来测试）

我们可以通过如下命令：

```shell

adb shell am broadcast -a android.intent.action.BOOT_COMPLETED

```

命令发送BOOT_COMPLETED广播，而不用重启测试机或模拟器来测试BOOT_COMPLETED广播。

我们还可以利用此命令更精确的发送到某个package：

```shell

adb shell am broadcast -a android.intent.action.BOOT_COMPLETED -p com.example.package

```

title: Android 布局方式
date: '2019-09-03 20:13:09'
updated: '2019-09-04 09:22:21'
tags: [Android]
permalink: /articles/2019/09/03/1567512789221.html
---
# Android 布局方式

# LinearLayout(线性布局)

线性布局由 LinearLayout 类来代表， LinearLayout 可以控制各组件横向或纵向排列。

## LinearLayout 常用属性介绍

1. android：orientation

　设置布局管理器内组件的排列方式，可设置为 horizon （水平排列）、vertical （垂直排列）。

``` xml

<?xml version="1.0" encoding="utf-8"?>

<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"

android:orientation="horizontal"

android:layout_width="match_parent"

android:layout_height="match_parent">

<Button

android:id="@+id/btn1"

android:layout_width="wrap_content"

android:layout_height="wrap_content"

android:text="@string/btn1"/>

<Button

android:id="@+id/btn2"

android:layout_width="wrap_content"

android:layout_height="wrap_content"

android:text="@string/btn2"/>

<Button

android:id="@+id/btn3"

android:layout_width="wrap_content"

android:layout_height="wrap_content"

android:text="@string/btn3"/>

</LinearLayout>

```

2.![](https://raw.githubusercontent.com/Marcello168/BlogPicture/master/ic_bg2%403x.png)

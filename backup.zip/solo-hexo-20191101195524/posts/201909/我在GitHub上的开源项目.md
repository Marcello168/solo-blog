title: 我在 GitHub 上的开源项目
date: '2019-09-04 19:45:23'
updated: '2019-09-16 18:22:26'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [react-native-SerialPort](https://github.com/Marcello168/react-native-SerialPort) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Marcello168/react-native-SerialPort/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/Marcello168/react-native-SerialPort/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/Marcello168/react-native-SerialPort/network/members "分叉数")</span>

React native Android 串口通讯 DLC



---

### 2. [react-native-modbus](https://github.com/Marcello168/react-native-modbus) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Marcello168/react-native-modbus/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/Marcello168/react-native-modbus/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Marcello168/react-native-modbus/network/members "分叉数")</span>

React native Modbus 协议



---

### 3. [dlc_demo_project](https://github.com/Marcello168/dlc_demo_project) <kbd title="主要编程语言">Dart</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Marcello168/dlc_demo_project/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/Marcello168/dlc_demo_project/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Marcello168/dlc_demo_project/network/members "分叉数")</span>





---

### 4. [solo-blog](https://github.com/Marcello168/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Marcello168/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Marcello168/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Marcello168/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.gongyonghui.cn`](http://www.gongyonghui.cn "项目主页")</span>

Marcello168个人博客 - 记录精彩的程序人生



---

### 5. [flutter_app](https://github.com/Marcello168/flutter_app) <kbd title="主要编程语言">Dart</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Marcello168/flutter_app/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Marcello168/flutter_app/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Marcello168/flutter_app/network/members "分叉数")</span>

flutter_app



---

### 6. [react-native-scan-gun](https://github.com/Marcello168/react-native-scan-gun) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Marcello168/react-native-scan-gun/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Marcello168/react-native-scan-gun/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Marcello168/react-native-scan-gun/network/members "分叉数")</span>

React native Scan Gun  Android 扫码枪 



---

### 7. [BlogPicture](https://github.com/Marcello168/BlogPicture) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Marcello168/BlogPicture/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Marcello168/BlogPicture/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Marcello168/BlogPicture/network/members "分叉数")</span>

博客图床



---

### 8. [react-native-BLEMonitoringManager](https://github.com/Marcello168/react-native-BLEMonitoringManager) <kbd title="主要编程语言">Objective-C</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Marcello168/react-native-BLEMonitoringManager/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Marcello168/react-native-BLEMonitoringManager/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/Marcello168/react-native-BLEMonitoringManager/network/members "分叉数")</span>

DLC React native  蓝牙工具


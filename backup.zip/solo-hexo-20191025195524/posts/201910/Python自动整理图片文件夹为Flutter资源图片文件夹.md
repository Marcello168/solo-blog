title: Python 自动整理图片文件夹为 Flutter 资源图片文件夹
date: '2019-10-13 16:39:03'
updated: '2019-10-13 16:51:06'
tags: [Flutter]
permalink: /articles/2019/10/13/1570955943394.html
---
## Flutter 为当前设备加载适合其分辨率的图像
[`AssetImage`](https://docs.flutter.io/flutter/painting/AssetImage-class.html) 了解如何将逻辑请求asset映射到最接近当前设备像素比例的asset。为了使这种映射起作用，应该根据特定的目录结构来保存asset
* …/image.png
* …/Mx/image.png
* …/Nx/image.png
* …etc.
其中M和N是数字标识符，对应于其中包含的图像的分辨率，也就是说，它们指定不同素设备像比例的图片

主资源默认对应于1.0倍的分辨率图片。看一个例子：

* …/my_icon.png
* …/2.0x/my_icon.png
* …/3.0x/my_icon.png

在设备像素比率为1.8的设备上，`.../2.0x/my_icon.png` 将被选择。对于2.7的设备像素比率，`.../3.0x/my_icon.png`将被选择。

如果未在Image控件上指定渲染图像的宽度和高度，以便它将占用与主资源相同的屏幕空间量（并不是相同的物理像素），只是分辨率更高。 也就是说，如果`.../my_icon.png`是72px乘72px，那么`.../3.0x/my_icon.png`应该是216px乘216px; 但如果未指定宽度和高度，它们都将渲染为72像素×72像素（以逻辑像素为单位）。

`pubspec.yaml`中asset部分中的每一项都应与实际文件相对应，但主资源项除外。当主资源缺少某个资源时，会按分辨率从低到高的顺序去选择 （译者语：也就是说1x中没有的话会在2x中找，2x中还没有的话就在3x中找）。
#### 加载图片

要加载图片，请在widget的build方法中使用 [`AssetImage`](https://docs.flutter.io/flutter/painting/AssetImage-class.html)类。

例如，您的应用可以从上面的asset声明中加载背景图片：

```dart
Widget build(BuildContext context) {
  // ...
  return new DecoratedBox(
    decoration: new BoxDecoration(
      image: new DecorationImage(
        image: new AssetImage('graphics/background.png'),
        // ...
      ),
      // ...
    ),
  );
  // ...
}

```

使用默认的 asset bundle 加载资源时，内部会自动处理分辨率等，这些处理对开发者来说是无感知的。 (如果您使用一些更低级别的类，如 [`ImageStream`](https://docs.flutter.io/flutter/painting/ImageStream-class.html)或 [`ImageCache`](https://docs.flutter.io/flutter/painting/ImageCache-class.html), 您会注意到有与缩放相关的参数)

## 上面就是 Flutter 加载合适的分辨率的原理 但是 有时候 我们的UI给回来的切图 的文件夹结构 并不是 上面的那个样子 比如 


* …/Video/my_icon.png
* …/Video/my_icon@2x.png
* …/Video/my_icon@3x.png
* …/Video/my_icon1.png
* …/Video/my_icon1@2x.png
* …/Video/my_icon1@3x.png

那这个时候 我们需要把 图片 整理为 
* …/Video/my_icon.png
* …/Video/my_icon1.png
* …/Video/2.0x/my_icon.png
* …/Video/2.0x/my_icon1.png
* …/Video/3.0x/my_icon.png
* …/Video/3.0x/my_icon1.png

如果是手动一个一个改的话 非常麻烦 所以我用python 写了一个整理 成flutter 需要的图片文件夹 的脚本 代码 如下 
```python
# -*- coding: utf-8 -*-

'''
@Author: gongyonghui
@Date: 2019-10-13 09:53:31
@LastEditors: gongyonghui
@LastEditTime: 2019-10-13 16:07:40
@Description: file content
'''
import os
import shutil

rootPath = os.getcwd()  # 获得当前路径 /home/dir1

print('当前路径-> %s' % rootPath)

# 移动文件

def movefile(srcfile, dstfile):
    fpath, fname = os.path.split(dstfile)  # 分离文件名和路径
    if not os.path.exists(fpath):
        os.makedirs(fpath)  # 创建路径
    shutil.move(srcfile, dstfile)  # 移动文件
    print("move %s -> %s" % (srcfile, dstfile))

# 获取图片路径

def getFilePath():
    L1X = []
    L2X = []
    L3X = []
    for root, dirs, files in os.walk(rootPath):  # 遍历该目录下所有文件 包括子目录
        for file in files:
            filePath = os.path.join(root, file)
            fileSuffix = os.path.splitext(filePath)[1]  # 获取文件后缀
            if fileSuffix == '.jpeg' or fileSuffix == '.png':
                pictureName = os.path.split(filePath)[1]
                if pictureName.find('@2x.jpeg') > 0 or pictureName.find('@2x.png') > 0:
                    L2X.append(filePath)
                elif pictureName.find('@3x.jpeg') > 0 or pictureName.find('@3x.png') > 0:
                    L3X.append(filePath)
                else:
                    L1X.append(filePath)
            else:
                L1X.append(filePath)
    return (L1X, L2X, L3X)  # 返回图片路径元组

path2x = rootPath+'/2x'
path3x = rootPath+'/3x'
if os.path.exists(path2x) == False:
    print('2x目录不存在 创建目录')
    os.makedirs(path2x)
else:
    print('2x目录已存在')
if os.path.exists(path3x) == False:
    print('3x目录不存在 创建目录')
    os.makedirs(path3x)
else:
    print('3x目录已存在')
for picture_list in getFilePath():  # 遍历图片元组
    for picturePath in picture_list:  # 拿到图片路径
        old_path, old_pictureName = os.path.split(picturePath)
        new_path = path2x + '/' + old_pictureName
        if old_pictureName.find('@2x.jpeg') > 0 or old_pictureName.find('@2x.png') > 0:
            new_path = path2x + '/' + old_pictureName.replace('@2x', "")
        elif old_pictureName.find('@3x.jpeg') > 0 or old_pictureName.find('@3x.png') > 0:
            new_path = path3x + '/' + old_pictureName.replace('@3x', "")
        else:
            new_path = rootPath + '/' + old_pictureName  # 1x 图片 放在根目录
            pass
        if os.path.exists(new_path):
            # print('%s 文件已存在' % old_pictureName)
            pass
        elif os.path.exists(picturePath) == False:
            print('%s 文件不存在 文件路径 %s' % (old_pictureName, picturePath))
        else:
            movefile(picturePath, new_path)  # 移动图片到指定路径
```

当然你也可以根据你的需求来修改代码   [github地址](https://github.com/Marcello168/flutter-picture-python)
